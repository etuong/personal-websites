﻿using System.Windows;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for ControlTemplateExample.xaml
    /// </summary>
    public partial class ControlTemplateExample : Window
    {
        public ControlTemplateExample()
        {
            InitializeComponent();
        }
    }
}
