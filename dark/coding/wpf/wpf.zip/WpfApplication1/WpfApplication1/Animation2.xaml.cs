﻿using System.Windows;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for Animation2.xaml
    /// </summary>
    public partial class Animation2 : Window
    {
        public Animation2()
        {
            InitializeComponent();
        }


    }
}
