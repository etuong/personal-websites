﻿using System.Windows;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for Basic_Styling.xaml
    /// </summary>
    public partial class BasicStyling : Window
    {
        public BasicStyling()
        {
            InitializeComponent();
        }
    }
}
