﻿using BasicMVVMExample.ViewModel;
using System.Windows;

namespace BasicMVVMExample
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            MainWindowView view = new MainWindowView();
            MainWindowViewModel vm = new MainWindowViewModel();
            view.DataContext = vm;
            view.Show();
        }
    }
}
