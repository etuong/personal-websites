﻿using BasicMVVMExample.Helper;
using BasicMVVMExample.Model;
using System;
using System.Collections.ObjectModel;

namespace BasicMVVMExample.ViewModel
{
    public class MainWindowViewModel : ViewModelBase
    {
        public DelegateCommand AddUserCommand { get; set; }
        public ObservableCollection<Person> People { get; set; }
        private Person _SelectedPerson;

        private string _SelectedItemString;
        public string TextProperty { get; set; }

        public MainWindowViewModel()
        {
            AddUserCommand = new DelegateCommand(OnAddUserCommand);

            People = new ObservableCollection<Person>
            {
                new Person { FirstName="Ethan", LastName="Uong", Age=32 },
                new Person { FirstName="Yvonne", LastName="Liu", Age=26 },
                new Person { FirstName="Happy", LastName="Doggy", Age=3 },
            };            
        }
        
        public Person SelectedPerson
        {
            get { return _SelectedPerson; }
            set
            {
                if (_SelectedPerson != value && value != null)
                {
                    _SelectedPerson = value;
                    SelectedItemString = value.FirstName;
                    OnPropertyChanged("SelectedPerson");
                }
            }
        }

        public string SelectedItemString
        {
            get { return _SelectedItemString; }
            set
            {
                if (_SelectedItemString != value)
                {
                    _SelectedItemString = value;
                    OnPropertyChanged("SelectedItemString");
                }
            }
        }

        private void OnAddUserCommand()
        {
            if (!string.IsNullOrEmpty(TextProperty))
            {
                People.Add(new Person {
                    FirstName = TextProperty.ToString(),
                    LastName = TextProperty.ToString(),
                    Age = DateTime.Now.Second
                });
            }
        }
    }
}
